# coding:utf-8

import os
import configparser

# print(os.path.realpath(__file__))
dir_path = os.path.dirname(os.path.realpath(__file__))
conf_path = os.path.join(dir_path, 'conf.ini')
conf = configparser.ConfigParser()
conf.read(conf_path)

smtp_server = conf.get('email', 'smtp_server')
port = conf.get('email', 'port')
sender = conf.get('email', 'sender')
pwd = conf.get('email', 'pwd')




