from selenium import webdriver
import time

url = 'http://maiziedu.com/'
login_text = '登录'
account = '1160869506@qq.com'
pwd = 'abc123456'


def login_test():
    d = webdriver.Chrome()
    d.get(url)
    time.sleep(3)
    d.maximize_window()
    time.sleep(2)
    d.find_element_by_link_text(login_text).click()
    time.sleep(2)
    account_ele = d.find_element_by_id('id_account_l')
    time.sleep(2)
    account_ele.clear()
    account_ele.send_keys(account)
    pwd_ele = d.find_element_by_id('id_password_l')
    time.sleep(2)
    pwd_ele.clear()
    pwd_ele.send_keys(pwd)
    d.find_element_by_id('login_btn').click()
    try:
        d.find_element_by_link_text('该账号格式不正确')
        print("Account And Pwd Error!")
    except:
        print("Account And Pwd Right!")

login_test()