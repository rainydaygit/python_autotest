# coding:utf-8
import unittest

class TestOne(unittest.TestCase):

    def setUp(self):

        print('TestOne_setup!!!!')

    def testTwo_01(self):
        self.assertEquals(1, 2)
        print('TestOne测试用例01！！！')

    def testTwo_02(self):
        print('TestOne测试用例02！！！')

if __name__ =='__main__':
    unittest.main()