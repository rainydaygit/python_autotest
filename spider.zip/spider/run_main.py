# coding:utf-8
import unittest
import os
import time
from common import send_email
from report import HTMLTestRunnerCN

class RunMain:

    def add_case(self, casename='case', rule='test*.py'):
        dir_path = os.path.dirname(os.path.realpath(__file__))
        case_path = os.path.join(dir_path, casename)
        discover = unittest.defaultTestLoader.discover(case_path, pattern=rule, top_level_dir=None)

        return discover

    def run_case(self, allcase, reportname='report'):
        now = time.strftime('%Y_%m_%d_%H_%M_%S')
        dir_path = os.path.dirname(os.path.realpath(__file__))
        report_path = os.path.join(dir_path, reportname)
        if not os.path.exists(report_path):os.mkdir(report_path)
        report_abspath = os.path.join(report_path, now+'test_report.html')
        with open(report_abspath, 'wb') as f:
            runner = HTMLTestRunnerCN.HTMLTestRunner(stream=f, title='自动化测试报告，测试结果：', description='用例执行情况：')
            runner.run(allcase)

    def get_new_report(self):
        dir_path = os.path.dirname(os.path.realpath(__file__))
        report_path = os.path.join(dir_path, 'report')
        report_list = os.listdir(report_path)
        report_list.sort(key=lambda fn: os.path.getmtime(os.path.join(report_path, fn)))
        report_file = os.path.join(report_path, report_list[-1])

        return report_file


if __name__ == '__main__':

    ru = RunMain()
    ru_case = ru.add_case()
    ru.run_case(ru_case)
    newre = ru.get_new_report()
    se = send_email.sendEmail(['zhujie@jianq.com', '15999635992@163.com'])
    #se.send_email_text('这是主题', '这是内容！！！！')
    se.send_email_multipart('带附件的主题!!!!!', newre)
