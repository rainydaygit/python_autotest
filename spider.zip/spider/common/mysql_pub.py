# coding:utf-8
import mysql.connector

mysql.connector.connect()